# MUSIAL WEB EXAMPLE DATASET
# AUTHOR: Simon Hackl
# CONTACT: simon.hackl@uni-tuebingen.de
# DATE: December 18th, 2022
#
# This dataset was collected to serve as an example in
# order to demonstrate the features of MUSIAL. In order
# to reproduce the results with the web interface, fill
# in the respective files in the form and add the line
# below to the `GENES TO ANALYZE` textfield:
#
# Name=tp92,Name=mutS
#
# DATA REFERENCES
# - The reference genome and annotation were extracted from
# the NCBI genome database (CP004010.2 Treponema pallidum 
# subsp. pallidum str. Nichols, complete genome)
# - The samples' raw date was collected from three BioProjects:
# PRJNA305961 (https://www.ncbi.nlm.nih.gov/bioproject/?term=PRJNA305961)
# PRJNA322283 (https://www.ncbi.nlm.nih.gov/bioproject/?term=PRJNA322283)
# PRJNA313497 (https://www.ncbi.nlm.nih.gov/bioproject/?term=PRJNA313497)
# - The final .vcf files were generated using GATK HaplotypeCaller
# (DOI: https://doi.org/10.1101/201178)
# - The tp92 protein structure was predicted using the Robetta webserver
# (DOI: https://doi.org/10.1126/science.abj8754)