# About the example dataset:

For the example dataset we have downloaded all paired-end read datasets listed on the M. tuberculosis NextStrain board (https://nextstrain.org/tb/global).
Genotyping was conducted with nf-core/eager (https://nf-co.re/eager) specifying the GATK HaplotypeCaller (https://gatk.broadinstitute.org/).
We have selected seven genes relevant for AMR for the example analysis;
- ethA, inhA, katG based on `https://www.ncbi.nlm.nih.gov/pmc/articles/PMC296216/`.
- gyrA, rpsL, pabC, ftsH based on `https://www.biorxiv.org/content/10.1101/2023.09.06.556328v1`.
The protein structures for the products of the seven genes were downloaded from UniProt (the AlphaFold2 predicted models) - note: The MODEL, ENDMODEL, DBREF and CRYSTX lines were removed from the .pdb files.

# How to submit the example dataset to MUSIAL:

1. Visit the website https://musial-tuevis.cs.uni-tuebingen.de/ and switch to the upload page.
2. Upload the files as follows:
    * Attach the m_tuberculosis_H37Rv.fasta file to the Reference Sequence input element.
    * Attach all .vcf files in the ./samples/ directory to the Samples>Variant Calls input element.
    * Attach the samples_meta_data.tsv to the Samples>Samples Meta Information input element.
    * Attach the m_tuberculosis_H37Rv.ggf3 file to the Genomic Features>Reference Sequence Annotation input element.
    * Enter the tags 'Name ethA', 'Name inhA', 'Name katG', 'Name ftsH', 'Name gyrA', 'Name rpsL' and 'gene_synonym pabC' into the Genomic Features>Features to Analyze text field.
    * Attach the seven .pdb files in ./protein_structures/ to the Proteoform Analysis/Protein Structures input element.
    * Set 'Minimal Variant Call Position Coverage' to 10, 'Minimal Variant Call Quality (Phred Scaled Error Probability)' to 100 and 'Minimal Homozygous Variant Call Frequency' to 80 in the Adjust Parameters fields.
3. Click on the submit request button on top, it has turned green after all necessary inputs (reference .fasta and .gff3 and at least one .vcf file) were attached.
4. After some time you will be redirected to the results page.