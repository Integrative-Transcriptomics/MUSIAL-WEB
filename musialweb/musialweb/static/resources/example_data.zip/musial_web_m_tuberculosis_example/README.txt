# About the example dataset:

For the example dataset we have downloaded all paired-end read datasets listed on the M. tuberculosis NextStrain board (https://nextstrain.org/tb/global).
Genotyping was conducted with nf-core/eager (https://nf-co.re/eager) specifying the GATK HaplotypeCaller (https://gatk.broadinstitute.org/).
We have selected three genes, ethA, inhA, katG, relevant for Ethionamide resistance (https://www.ncbi.nlm.nih.gov/pmc/articles/PMC296216/) for the example analysis.
The protein structures for the products of the three genes were downloaded from UniProt (the AlphaFold2 predicted models) - note: The MODEL and ENDMODEL lines were removed from the .pdb files.

# How to submit the example dataset to MUSIAL-WEB:

1. Visit the website https://musial-tuevis.cs.uni-tuebingen.de/ and switch to the upload page.
2. Upload the files as follows:
    * Attach the m_tuberculosis_H37Rv.fasta file to the Reference Genome input element.
    * Attach all .vcf files in the ./samples/ directory to the Samples>Variant Calls input element.
    * Attach the samples_meta_data.tsv to the Samples>Samples Meta Information input element.
    * Attach the m_tuberculosis_H37Rv.ggf3 file to the Genomic Features>Genome Annotation input element.
    * Enter Name=ethA,Name=inhA,Name=katG into the Genomic Features>Genes to Analyze text field.
      This will tell MUSIAL to match and analyze only features with a Name=ethA, Name=inhA or Name=katG field in the .gff3 files properties column.
    * Attach the three .pdb files in ./protein_structures/ to the Protein Analysis/Protein Structures input element.
3. Click on the submit request button on top, it has turned green after all necessary inputs (reference .fasta and .gff3 and at leas one .vcf file) were attached.
4. After accepting a cookie, you will see a wiggling bacteria indicating your request is being processed. After some time you will be redirected to the results page.